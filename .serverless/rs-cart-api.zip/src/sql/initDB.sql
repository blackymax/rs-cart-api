create table if not exist carts (
	id uuid primary key default uuid_generate_v4(),
	user_id text,
	created_at text,
	updated_at integer,
	foreign key(user_id) references users(id)
)



create table if not exist cart_items (
	id uuid primary key default uuid_generate_v4(),
	cart_id uuid,
	product_id uuid,
	count integer,
	foreign key(cart_id) references carts(id),
	foreign key(product_id) references products(id)
)


create table if not exist orders (
	id uuid primary key default uuid_generate_v4(),
	user_id uuid,
	cart_id uuid,
	payment json,
	delievery json,
	comments text,
	status text,
	total integer,
	foreign key(user_id) references users(id),
	foreign key(cart_id) references carts(id)
)

create table if not exist users (
	id uuid primary key default uuid_generate_v4(),
	name text,
	password text,
	email text
)