import { Injectable } from '@nestjs/common';
import { InjectClient } from 'nest-postgres';
import { Client } from 'pg';

import { Order } from '../entities/order.entity';

@Injectable()
export class OrderService {
  constructor(@InjectClient() private readonly pg: Client) {}

  async findById(orderId: string): Promise<Order> {
    const orders = await this.pg.query(
      `SELECT * FROM orders WHERE id=$1 LIMIT 1`,
      [orderId],
    );
    return orders.rows[0];
  }

  async create(data: any) {
    const { user_id, cart_id, payment, delievery, comments, total } = data;

    const orders = await this.pg.query(
      `INSERT INTO orders (user_id, cart_id, payment, delivery, comments, total, status) LIMIT 1 RETURNING *`,
      [user_id, cart_id, payment, delievery, comments, total, 'inProgress'],
    );

    return orders.rows[0];
  }

  async updateById(orderId, data): Promise<any> {
    const {
      user_id,
      cart_id,
      payment,
      delievery,
      comments,
      total,
      status,
    } = data;
    const orders = await this.pg.query(
      `UPDATE orders SET (user_id = $1, cart_id = $2, payment = $3, delivery = $4, comments = $5, total = $6, status = $7) WHERE id=$8 LIMIT 1`,
      [user_id, cart_id, payment, delievery, comments, total, status, orderId],
    );
    return orders.rows[0];
  }
}
